varUsername = "python123  test  i am html"

if "HTML" in varUsername: # string to search "python123"
    print("found")
else:
    print("not found")

#Exercise
# find the first vowel in your fullname 

#Extension
# search using the or for all the vowels in your full name
# a or e or i or o or 