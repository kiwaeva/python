varWords = "This is python bootcamp"
count = 0
varChar = input("Enter a character to search for: ")


for aLetter in varWords: # aLetter is a variable that will iterate over the varWords and store each character
    if aLetter == varChar: # aLetter will compare each charater in varWords with character enter in varChar
        count = count + 1 # count the character and increase by 1, if more than 1
print("The character", varChar, "appears", count, "times")

varChar = input("Enter a character to search for: ")
#exercise
# add an elif/else block if the letter is not found
# careful with indentation
