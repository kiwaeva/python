# chr(): takes a decimal and returns the ascii equivalent
# ord(): takes a character and returns the decimal equivalent
 
varMsg = "" # initialise variable without a value but is of string datatype

varNum = int(input("Enter a number: "))
varConvert = chr(varNum) # invoke/call the chr function  to convert number to an ascii equivalent
varMsg = varMsg + varConvert

print(varMsg)

