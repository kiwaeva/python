aList = [1,2,3,4,5]
bList = ["Paul", "Anna", -5, 10.1]

print("This is a list:",aList)

print("This is b list:",bList)

listAB = [aList] + [bList] # h eplus operator is used to join/concatenate aList and bList

print("This is alist and bList combined:",listAB)

