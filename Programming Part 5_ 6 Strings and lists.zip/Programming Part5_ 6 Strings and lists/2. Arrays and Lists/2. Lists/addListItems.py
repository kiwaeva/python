aList = [1,2,3,4,5]
bList = [7,8,8,11,21]

print(type(aList))

listAB = [aList [i] + bList[i] for i in range(len(bList))]

print(listAB)


aList = [1,2,3,4,5]
bList = [7,8,8,11,21, 30]

listAB = [aList [i] + bList[i] for i in range(len(aList))]

print(listAB)


