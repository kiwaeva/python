def aphabetList (): # creae function
    alphaList=[] # create an empy list
    for letters in range(60, 100): # specify the start and end values to be iterated over
        alphaList.append(chr(letters)) # append/add the convereted values to the list
    return alphaList

print(aphabetList())


print(bin(21))

