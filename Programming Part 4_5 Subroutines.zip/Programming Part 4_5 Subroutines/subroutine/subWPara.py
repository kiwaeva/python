


def addNums(par1,par2, par3): # parameter used in a subroutine to allow values to be passed into them. 
    answer = par1 + par2 + par3 # create answer variable to store the reult of the addition 
    print("The answer is", answer)
    # inside of the subroutine

#Argument: are the values held in the brackets of a subroutine call.
#  These are passed into a subroutine via the parameters. 
num1 =  int(input("Enter your first number"))
num2 =  int(input("Enter your second number"))
num3 =  int(input("Enter your third number"))
addNums(num1, num2 , num3) #passed variables as argument 


addNums("Paul", "Anna", "James") #passed string values as argument 




addNums(200, 300, 12) # passed hardcoded/staric numeric values as argument 


addNums(20.3, 1.30, 0.99)



# addNums(2300, 3030)

#Exercise 3 (With parameters)
#create a subroutine to  either  subtact, divide or multiply 
# Ask for two numbers
# evaluate the two numbers
# add two arguments 
# display the answer
