# subroutine:A sequence of instructions to perform a specific task with an identifiable name.

# def is a keyword used define a subroutine, followed by the name of the subroutine

def username(): # define subroutine and give it a name
    name = input("Enter you name: ")
    print("Thanks for joning us", name)


username()  # call the subroutine locally, inside its own file.


# Exercise 1: create subroutine 
# ask for firstname, lastname , age and favourite movie
# call the subroutine locally/ within he program
# call the subroutine in another file/ in another program
