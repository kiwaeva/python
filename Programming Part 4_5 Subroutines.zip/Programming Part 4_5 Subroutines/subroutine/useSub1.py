import sub1

print("This is Python Bootcamp")

# print("This is Python Bootcamp")
# print("This is Python Bootcamp")
# print("This is Python Bootcamp")

sub1.username() #call the subroutine in another file , outside its own file.