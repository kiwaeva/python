globalVar = 20  #"global Var", 

print(globalVar)


globalVar= 10 #"global Var", 
print("Global Var", globalVar)  


def localVar():
    globalVar = 1 # local variable
    return globalVar


print(globalVar) 

testLocal = localVar()

print("Local Var", testLocal)


# ask for user name
def username():
    name = input("enter you name: ")

# ask for ticket price 
def ticke():
    tkPrice = int(input("enter you name: "))


print("Welciome Python Adventures Theme park")

ticke()


