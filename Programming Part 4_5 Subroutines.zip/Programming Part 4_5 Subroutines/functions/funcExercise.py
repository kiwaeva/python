#Exercise modify the addNumbers function to add parameters and arguments

# whatever is passed inside the bracket of the function when the function is created is a parameter
def addNumbers(par1, par2): # define function and give it a name
    answer = par1 + par2 # using parameer as place to perfrom addiion
    return answer


# Whatever is passed inside the funtion brackets when the function is called "is an argument"
solution = addNumbers(10, 12) # passed in values as arguments
solution2 = addNumbers(23, 13)
print("The anser is ", solution)



num1 = int(input("Enter a number ")) # 5
num2 = int(input("Enter a number "))# 10
solution3 = addNumbers(num1, num2)  # passed in variables as arguments
print("The answer is ", solution3)

