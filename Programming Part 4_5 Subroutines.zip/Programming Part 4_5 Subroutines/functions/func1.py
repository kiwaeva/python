# A subroutine is a sequence of instructions to perform a specific task with an identifiable name.
# A function is a type of a subroutine that returns a value.

def addNumbers(): # define function and give it a name
    num1 = 10
    num2 = 30
    answer = num1 + num2
    return answer #  A value that is returned by a function.

print("The answer is answ",addNumbers()) # call the addNumbers functiion in the print statement

funcAnswer = addNumbers() #assign the function to a variable
print("The answer is", funcAnswer)

print (2+ 5 + funcAnswer)


#Exercise modify the addNumbers function to add parameters and arguments


