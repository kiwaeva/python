#Selection is used to control the flow of the program

# Comparison operator compare values
# == equal 
# < 	less than
# > 	more than/greater than
# <= 	less than or equal to 
# >= 	greater than or equal to
# !=    Not equal to 

pStudy = input("Enter your program of study: ")

if pStudy == "Bootcamp":# equality operator to compare user input with value "Bootcamp"
    print("Welcome to ", pStudy)# will be printed if condition is met on line 13
else: # execute if the condition on line 13 is not met
    print("Please enquire about our program of study")

pStudy1 = input("Enter your program of study: ")
if pStudy1 != "Bootcamp":# not equal operator to compare user input not equal "Bootcamp"
     print("Please enquire about our program of study")
else: # execute if the condition on line 19 is not met
    print("Welcome to ", pStudy1)# will be printed if condition is met on line 19

# Exercise 1 : use the equality and not equal to operators 
# To check if the user enter their first name as your firstname
# Print out a message when the condition(firname = your firstname) is met or not met  