#Selection is used to control the flow of the program

# Comparison operator compare values
# == equal 
# < 	less than
# > 	more than/greater than
# <= 	less than or equal to 
# >= 	greater than or equal to
# !=    Not equal to 

# score = 29 
score = int(input("Enter a number: "))

if score >29: # The 'if' checks the condition using the > comparison operator
    print("You are a Pythonista") # this will be printed if the condition is met
print("The end") 

#Exercise 1 any operator to ensure that the print statement on line 14 is executed

#Exercise 1 solution
if score >=29: # The 'if' checks the condition using the > comparison operator
    print("You are a Pythonista") # this will be printed if the condition is met
print("The end") 

if score ==29: # The 'if' checks the condition using the > comparison operator
    print("You are a Pythonista") # this will be printed if the condition is met
print("The end") 

score = 30
if score >29: # The 'if' checks the condition using the > comparison operator
    print("You are a Pythonista") # this will be printed if the condition is met
print("The end") 