#Selection is used to control the flow of the program

# Comparison operator compare values
# == equal 
# < 	less than
# > 	more than/greater than
# <= 	less than or equal to 
# >= 	greater than or equal to
# !=    Not equal to 

mark = int(input("Enter a student mark: "))

if mark >=75: # check input from user with value 
    grade = "A" # set the grade value to A if condition is met on line 13

elif mark>=60:
    grade = "B"

elif mark>=50:
    grade = "C"

else:
    grade = "F"

print("You scored", mark, "and your grade is:", grade)

