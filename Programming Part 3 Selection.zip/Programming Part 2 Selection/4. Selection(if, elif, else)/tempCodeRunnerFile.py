
print("You scored", mark, "and your grade is: ", grade)