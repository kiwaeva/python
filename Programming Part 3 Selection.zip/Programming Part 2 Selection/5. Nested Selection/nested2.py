#When a selection block(if/else) is placed within another
#selection block is called a nested selected

userAge = int(input("Enter your age: "))
if userAge >16: #check user input with the value set in the condition
    # will execute if condition on line 5 is met
    course = int(input("Enter the number of courses you are enrolled on: "))
    if course >2:#check user input with the value set in the condition
        print("Impressive, you enrolled on", course, "courses")# if line 8 is met
    else:  # will execute if condition on line 8 is not met
        print("You should enrol on more courses")
else: # will execute if condition on line 5 is not met
    print("Hope you enrolled on mor courses when you turned 17")
    


