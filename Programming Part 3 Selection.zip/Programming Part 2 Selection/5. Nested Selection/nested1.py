#When a selection block(if/else) is placed within another
#selection block is called a nested selected


userName = input("Enter username: ")
if userName == "python": #comare user input with value python
    userPassword = input("Enter password: ")#execute only if condition on line 6 is met
    if userPassword == "pass":# nested a second if inside another if statement
        print("Access granted")# execute only if condition on line 8 is met
print("closing")
