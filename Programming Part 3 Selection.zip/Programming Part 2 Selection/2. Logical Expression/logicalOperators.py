# Comparison operator compare values
# ==    equal  ( 2 == 2)
# < 	less than
# > 	more than
# <= 	less than or equal to 
# >= 	greater than or equal to
# !=    Not equal to 

#Logical expressions evaluate to True or False
#Logical operators: and, or , not

num1 = 15 #use assignment operator(=) to assign 15 to num1 variable
num2 = 20#use assignment operator(=) to assign 20 to num2 variable

# print((num1==25))
print((num1==15 and num2==20))# returns true as both sides of equation equates to true
print((num1==25 and num2==20))# returns false as one side of equation equates to False

#Exercise1 use the or operator to return an equation that equates to  True

#Exercise1 solution
print((num1==15 or num2 ==25)) #return true as one of equation equates to true
print((num1==15 or num2 ==20)) #return true as one or more of equation equates to true
print((num1==10 or num2 ==5)) #return false as both of equations equates to false
print("Line")
print(not(num1==15 and num2==20))# returns false as the "not"  both sides of the equation 

#Exercise2: use the Not operator to return an equation that equates to True
#Exercise2: Solution
print(not(num1==25 and num2==20))# returns true as one side of equation equates to True
print(not(num1==25 and num2==21))# returns true as both sides of equation equates to True

#Exercise3: use the Not operator with or operator to return an equation that equates to True and False

print("Exercise3 solution")
#Exercise3 solution
print(not(num1==25 or num2==21))# returns true As both sides are inside not
print(not(num1==25 or num2==20))# returns False as one side of equation equates to True
