# Arithmetic expressions evaluate to a number

num1 = 10
num2 = 5
num3 = 11
num4 = 2

#use of + operator
print("Addition: ", num1, " + ", num2, "=", num1 + num2)

#Exercise 1
# Use of - operator : Subtract
# Use of * operator : Multiplication
# Use of / operator : Division
# Use of // operator : Floor division/integer quotient
# Use of % operator : Mod/modulus
# Use of ** operator : power


#Exercise 1 Solution
# Use of * operator
print("Multiplication: ", num3, "*", num4, "=", num3 * num4)
# Use of / division operator to calculate answer with the remainder
print("Division: ", num3, "/", num4, "=", num3 / num4)
# Use ofinteger quotient operator to calculate answer without remainder
print("Integer Division: ", num3, "//", num2, "=", num3 // num2)
# Use of % Mod/Modulo operator to calculate only the remainder
print("Modulo operator: ", num3, "%", num4, "=", num3 % num4)
# Use of ** Power operator
print("Power operator: ", num3, "**", num4, "=", num3 ** num4)

print("Power operator: ", num4, "**", num4, "=", num4 ** num4)


