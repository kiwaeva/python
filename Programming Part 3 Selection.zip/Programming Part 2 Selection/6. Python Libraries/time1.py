import time

name1 = "paul"

time.sleep(3) # invoke the class with the sleep method an pass in the seconds as argument


print(name1)