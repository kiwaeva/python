"""Python Libraries are a set of useful functions 
that eliminate the need for writing codes from scratch.
"""

import math # import the math library so it can be used
radius = float(input("Enter radius: "))
# invoke the math.pi method from the math library
area = math.pi * radius ** 2

print("The area is: ", area)

