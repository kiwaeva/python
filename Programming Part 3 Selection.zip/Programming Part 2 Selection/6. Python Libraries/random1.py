# import random
from random import randint

randNums1 = randint(1,6)
randNums2 = randint(1,6)

print("The random number is ",randNums1)
print("The random number is ",randNums2)

print("\nThe random number are ",randNums1, randNums2)

#Homework1 use if else 
# to print out if a double is thrown
#to print out if a double is not thrown


#Homework 2: Modify homework1 use comparison operators
# randNums2 = randint(1,10) # hardcode ranom range 
# to ask for one user input between 1 and 10
# to print out if a double is thrown
# to print out if a double is not thrown