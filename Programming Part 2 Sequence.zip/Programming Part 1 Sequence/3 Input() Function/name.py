# ~ input function: allow the program to take a user input from the user 

print("What is your name? ") #diplay/out the question "What is your name"
# use str function to tell python you are expecting s string data type
name = str(input()) # invoke the input function to capture user data
print("Your name is:",name)

# ~ efficient coding practice
name1 = str(input("What is your name?: ")) # asking for user input dynamically
print("Welcome",name1)