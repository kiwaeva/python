#A variable holds a value in a memory location that is needed
# for the execution f your program.
#A variable can only hold one value at a time. this value can change 
#throuhout the execution of the program

# Variables must be declared before they can be used.
#declare and assign values to the respective vairables; num1, num2, num3
num1 = 10 
num2 = 20
num3 = 30
answer1 = num1 + num1 
answer2 = num3 * num2
answer3 = answer1 + answer2

name1 = "John" # declare variable name1 and assign the value John
print("Welcome", name1)
name1 = "Peter" # the value of name1 variable is now "Peter"
print("Welcome", name1)


print("This is the first answer:", answer1)

print("This is the seconds answer:", answer2)

print("This is the third answer:", answer3 )



# variable naming convention
username = "jsmsih" # meaningful variable name
username1 = "paul125"
firstName = "Anna" # camel notation
firstname = "Jane" # varaibles are case sensitive
last_name = "Wilson"
last_Name = "Jameson"
userAge = 23
age = 24

# £errr = "money"  can use a synbol
# AGE = 12 variable name should no be in all upper cases
# Username = "toby345" # dont start variable names with upper case character
# 2username = "Coder112345" #dont start variable names with number
# user name = "test user" # no spaces between variable name/s



# Task 2 modify your programs written in task 1 
# Use variables instead of static value: for example 
# declare vairable and assign value to them as shown num1 = 2
# Exercise: use the print statement to print 
# Your name
# Your address
# Your interests
# Perform either addition or calculation with two numbers
# Use text in your addition 
