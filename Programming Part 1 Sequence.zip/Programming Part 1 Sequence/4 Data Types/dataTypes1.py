# Boolean data types
# Boolean is yes/no or true or false (0 = off and 1 = on)
boolVal1 = True # declare and assign a boolean type variable with value True
boolVal2 = False # declare and assign a boolean type variable with value False



# String data types
string1 = "I love python, with double quotes" # use "" for single line string value assigment 
# use '' for single line string value assigment 
string2 = ' Python is the in demand programming language, with single quote'
# use """""" for multi line string value assigment 
string3 = """
This is multiline, 
This is multiline, 
This is multiline, 
This is multiline, 
"""

# ~string comments
"This is a comment"

"""
This is a multiline comment 
This is a multiline comment 
This is a multiline comment 
"""



# Numeric data types
num1 = 20.5 # float(decimal) variable declaration and assigment 
num2 = 20 # integer variable declaration and assigment

print(type(boolVal1))
print(type(boolVal2))

print(type(string1))
print(type(string2))
print(type(string3))

print(type(num1))
print(type(num2))
