# Use hash tag to write a comment 
# Sequence in programming is a set of instructions performed in order, 
# with each executed in turn.
print(2 * 10)
print("The answer to 2 + 3:\n",2 + 3, "\nInstruction number 2") # \n prints in a newline
# the intepreter prints anything within a speech marks or quotes as it it
print("Welcome to python programming") #display/output code or text within the brackets

print("This is cohort 3 3")

# Task 1
# Exercise: use the print statement to print 
# Your name
# Your address
# Your interests
# Perform either addition or calculation with two numbers
# Use text in your addition 