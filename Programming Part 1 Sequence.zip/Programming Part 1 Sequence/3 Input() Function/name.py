# ~ input function: allow the program to take a user input from the user 

print("What is your name? ") #diplay/out the question "What is your name"
name = input() # invoke the input function to capture user data
print("Your name is:",name)

# ~ efficient coding practice
name1 = input("What is your name?: ") # asking for user input dynamically
print("Welcome",name1)