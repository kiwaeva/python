num1 = int(input("Enter your first number: "))


# Task 3: using input function
# complete  the rest of the code
# Use a variable and invoke the input function  to ask the user for a second number
# add the two numbers
# print out the total of the two numbers