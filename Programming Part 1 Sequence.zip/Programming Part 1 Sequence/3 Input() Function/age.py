#The default data type of the input function is string

userAge = int(input("please enter your age: ")) # use it function with input to caputre int value
print("Your age is:", userAge)