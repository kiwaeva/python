
# num1 = int(input(" enter a number "))
# num2 = int(input(" enter a number "))
# num1 = 12
# num2 = 0
# num3 = num1/num2
# print(num3)

try:
    # num1 = 12
    # num2 = 0
    num1 = int(input(" enter a number "))
    num2 = int(input(" enter a number "))
    num3 = num1/num2
    print(num3)
except ZeroDivisionError:
    print("You can't divide a number by zero\nenter a number that is not zero")
finally:
    print("closing the program")

