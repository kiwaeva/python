import logging

# logging levels

logging.basicConfig(filename="Log2.log", level=logging.DEBUG) # set the minimum logging level 
logging.critical("critical")
logging.error("error")
logging.debug("debug")
logging.warning("warning")
logging.info("info")