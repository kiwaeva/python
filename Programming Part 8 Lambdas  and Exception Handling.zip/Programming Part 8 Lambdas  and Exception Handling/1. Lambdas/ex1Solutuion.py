# ~exercise modify program below to ask user to input number
addTwoNums =  lambda num: num + 10  # the expression is num + 10 

userNum = int(input("Enter a number: "))

print("The answer to", userNum, "+" , 10, ":",  addTwoNums(userNum)) 

addTwoNums =  lambda num: num + 10   
print(addTwoNums(int(input("Enter number: "))))


x3 = int(input("Enter a number 1-10: "))
y3 = int(input("Enter another number 1-10: "))

multiNums2 = lambda x3, y3: x3 - y3 
print(multiNums2(x3, y3))
