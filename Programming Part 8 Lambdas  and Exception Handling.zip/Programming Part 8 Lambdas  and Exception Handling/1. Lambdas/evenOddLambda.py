evenNum = lambda num: 'This is an even number' if num%2==0 else 'This is an odd number'
evenOddNum = int(input("Enter a number: "))
print(evenNum(evenOddNum))
