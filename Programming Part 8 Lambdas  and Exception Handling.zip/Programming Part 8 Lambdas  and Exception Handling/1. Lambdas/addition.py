# A lambda is simply a way to define a function in Python. They are sometimes known as "lambda 
# operators" or "lambda functions".  A lambda function is a small anonymous function, they are functions
# that don't need to be named. They are used to create small, one-off functions in cases where a "real "
# function would be too big and bulky.   A lambda function can take any number of arguments, but can 
# only have one expression. lambda arguments : expression .

# Lambdas return a function object, which can be assigned to a variable. Lambdas can have any number
#  of arguments, but they can only have one expression. You cannot call other functions inside lambdas.

"lambda arguments: expressions"

# variable  = lambda parameter : expressions
addTwoNums =  lambda num: num + 10  # the expression is num + 10

print(addTwoNums(2)) # the number 2 is the argument that get passed into the parameter


sumOfNums = lambda num1, num2: num1 + num2  + 10 + 12
print("\nThe answer is",sumOfNums(5, 11))


sumOfNums = lambda num1, num2, num3: num1 + num2 + num3 + 10 + 12
print("\nThe answer is",sumOfNums(5, 11, 45))


#exercise 
# perform multiplication with one parameter and  one argument
# perform multiplication with two parameters and two arguments
# perform multiplication with three parameters and three arguments

# ~exercise modify program below to ask user to input number
addTwoNums =  lambda num: num + 10  # the expression is num + 10 
# add code here to ask for user input 
print(addTwoNums()) 