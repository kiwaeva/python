varSubString = lambda myString: myString in "This is python bootcamp"
testString = 'This' 
print(varSubString('is')) # True
print(varSubString('bootcamp')) # True
print(varSubString('I')) # False
print(varSubString('Amit')) # False
print(varSubString('CSS'))# False
print(varSubString('python')) # True
print("\nUse variabble")
print(varSubString(testString)) # True