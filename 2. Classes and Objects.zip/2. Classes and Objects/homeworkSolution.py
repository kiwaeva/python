# Task2:
# •	Create a new  instance object from the class MobilePhone
# •	Modify the values by using the class variables (make, description, model and price) to ask for user input.
# •	Print the values stored  in the variables 


class MobilePhone:
    def __init__(self):
        self.make = "Samsung"  #name is Property/Variable and "Samgung" is the value held in variable name
        self.description = "Slim Buid, touch screen"
        self.model = "Galaxy S10"
        self.price = "945"
mobile1 = MobilePhone() #Create a new  instance object from the class MobilePhone
print("Before modifying the value held in the make variable, value is", mobile1.make)
#modify the value geld in the make variable to "testMobile"


mobile1.make =  input("Enter phone make/brand: ")
mobile1.description  = input("Enter phone description: ")
mobile1.model  =  input("Enter phone model: ")
mobile1.price  =  float(input("Enter phone price: "))

print("After modifying the value held in the make variable, value is", mobile1.make)
print("After modifying the value held in the description variable, value is", mobile1.description)
print("After modifying the value held in the model variable, value is", mobile1.model)
print("After modifying the value held in the price variable, value is", mobile1.price)
