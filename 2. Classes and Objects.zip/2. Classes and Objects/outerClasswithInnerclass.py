class MobilePhone: #outer class
    def __init__(self,phoneMake, phoneDes, phoneModel, phonePrice ):
        self.make =   phoneMake # "String Variable"
        self.description = phoneDes
        self.model = phoneModel
        self.price = phonePrice # 1234.7 = float data type
    
    class IMEInumber: # inner class
        def __init__(self, imeiNo, fSize):
            self.number = imeiNo
            self.fontSize = fSize

#exercise add and then access the third paramter in the innerClass IMEInumber

# create another inner class call screenSize with only one parameter 
# print the value of the screensize paramter 

mobile1 = MobilePhone("OnePlus", "Black Slim Titanium", 10, 1203.31)
print(mobile1.make)
print(mobile1.description)
print(mobile1.model)
print(mobile1.price)

#access inner class
# create an insance object to access the inner class
m2 = MobilePhone("HTC","Outdated", "Unavailable", 156.22)

phoneIMEINo = m2.IMEInumber(34567890, "Size12")

print(phoneIMEINo.number)
print(phoneIMEINo.fontSize)
# IMEInumber()
