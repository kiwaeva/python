num = int(input("Enter a number to generate a multiplication table: "))# prompt for user input
for multiplyby in range(1,13):# loop from start to end value/range
    print(num, "X", multiplyby, "=",  num * multiplyby )  # returnt the looped result