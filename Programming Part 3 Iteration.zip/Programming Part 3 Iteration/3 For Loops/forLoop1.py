import time # import the time library
# Iteration means repetition
# A for loop is another tool to control the flow of execution in your programs. 
# for loops is used when you have definite iteration 
# (the number of iterations is known). 

# number of iteration specified as 10 as argument in the range 
# function, counting 10 items starting from zero
for number in range(10):
    print(number)


for number in range(5,16): # start and stop value passed as arguments in the range function
     time.sleep(1)
     print("With start and stop values")
     print(number)


for number in range(5,50,10): # start,stop, step value passed as arguments in the range function
    time.sleep(1)
    print("With start, stop and step values")
    print(number)



for number in range(5,50,10): # start,stop, step value passed as arguments in the range function
    time.sleep(1)
    print(number)

# Exercise 1
# Create timer that will count up to 50
# Increase the count by 1 every second
# Specify the start value to be 1
# Ensure the count include the number 50 as the end value
