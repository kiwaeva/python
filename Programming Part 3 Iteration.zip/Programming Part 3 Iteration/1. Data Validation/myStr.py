name = input("enter your name: ")

if name.isdigit(): # check if there is is a digit at the start
    print("Use letters at the start of your name")
else: 
     print("Your name is", name)
