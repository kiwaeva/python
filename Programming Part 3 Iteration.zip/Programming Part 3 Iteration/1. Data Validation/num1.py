number = int(input("enter a number: "))
print("You entered:", number)
print("You handled the error")


# exercise 1 : Handle the value error
# use the previous example as a guide 
# to handle the value error
# use try and except block

try:
    number = int(input("enter a number: "))
    print("You entered:", number)
except ValueError:
    print("Enter a numeric value")
print("You handled the value error")





