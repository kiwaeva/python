
num1 = 5 # assign static value to a variable
while(num1 <=20): #check condition that num1 is less han but equal to 20
    print(num1)
    num1+=2  # increment the num value by 1



# exercise 1
# write a program that will ask the user to guess your firstname
# continue to ask the user if they dont guess your name correctly
#print out your name when the user guessed it correctly and end the program

#exercise 2
# write a prgram that ask the user for a number below 5
#count from the number the user entered to 25
# print the count
#end the program

# Homework : countdown timer