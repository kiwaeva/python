# The While loop keeps going until the condition is met (unknown number of times). 

guessWord = input("Guess a word:")
while guessWord != "python":# comapre and check input value with the value "python"
    guessWord=input("Try to again to guess a word: ") #execute when condition is not met 
print("Well done ...you guessed", guessWord)#execute when condition is not met
