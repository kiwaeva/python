# Regular expressions are patterns that help a user match character combinations 
# in text files and strings. You can use regular expressions to filter or find a
# specific pattern in the output of a  command or a document.
#  Import the re module:

import re # import the module



# text/string to search
sentence = "Taken up Two one Too  2idea, Tame ne1idea o1234 at a oWN oWNer 4 time one open old older olga"
'''The RegEx Match method used, takes a regular expression 
and search for that pattern right at the beginning of the string '''


searchResult = re.match(r'T\w\w', sentence)

 # only invoke the group method if the result which comes back is Match the substring at the start
# print(searchResult.group())

print(searchResult)