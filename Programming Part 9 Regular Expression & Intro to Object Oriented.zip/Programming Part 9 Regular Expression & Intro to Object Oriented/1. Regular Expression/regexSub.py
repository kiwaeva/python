# Regular expressions are patterns that help a user match character combinations 
# in text files and strings. You can use regular expressions to filter or find a
# specific pattern in the output of a  command or a document.
#  Import the re module:

import re # import the module



# text/string to search
sentence = "Take up one2idea, One1idea o1234 at a oWN oWNer 4 time one open old older olga"

''' The sub method, substitute the given string with a new string using the given RegEx 
format passed in'''''

#use search method to define search parameter and assign it to a variable

# second parameter specified inthe sub function replaces the first parameter 
searchResult  = re.sub(r'one', 'two', sentence)
print(searchResult)


#exercise substitute any substring that starts with
# the letter o regardless of the number of characters 
# that follows after 
# solution
searchResult  = re.sub(r'o\w+', 'two', sentence)
print(searchResult)

# findall function 
'''' RegEx findall method searches a string from the beginning to the end of the string, and return all the sub-string 
that matches the given regular expression in a list and returns an empty list if no match is found. '''

searchResult  = re.findall(r'o\w\w', sentence) # find substring with 3 characters that start with o
print(searchResult)

searchResult  = re.findall(r'o\w+', sentence) # find substring with 3 characters that start with o
print(searchResult)